package com.packt.microservices.geolocation;

import io.dropwizard.Configuration;

public class GeoLocationConfiguration extends Configuration {

}
